aws translate translate-text \
  --region eu-north-1 \
  --source-language-code "fi" \
  --target-language-code "en" \
  --text "$(cat kysymys)" | grep -v -e Source -e Target -e '}' -e '{' | sed 's/.\{1\}$//' | sed 's/^.\{22\}//' | sgpt
