while true; do
    sh asker.sh && sh aWsReGeX.sh
done
