#!/bin/bash

# Prompt the user for input
read -p "Kysy minulta: " userInput
printf '\n'

# Pipe the input forward
echo "$userInput" > kysymys
