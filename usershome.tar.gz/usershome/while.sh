#while true; do
for ((i=1; i<=10; i++)); do
    sh asker.sh
    printf '\n\n\n'
done
systemctl reboot
